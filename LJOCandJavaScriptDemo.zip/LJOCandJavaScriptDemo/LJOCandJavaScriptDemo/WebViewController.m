//
//  WebViewController.m
//  LJOCandJavaScriptDemo
//
//  Created by apple on 2018/6/12.
//  Copyright © 2018年 lj. All rights reserved.
//

#import "WebViewController.h"
#import <WebKit/WebKit.h>   //导入WKWebView

@interface WebViewController ()<WKNavigationDelegate, WKUIDelegate> //代理方法
@property (nonatomic, strong) WKWebView *webView;
@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
    
}

- (void)configureUI {
    self.webView = [[WKWebView alloc] initWithFrame:self.view.frame];
    //加载本地html
    NSString *path = [[NSBundle mainBundle] pathForResource:@"prize.html" ofType:@""];
    NSURL *baseUrl = [NSURL fileURLWithPath:path];
    [self.webView loadFileURL:baseUrl allowingReadAccessToURL:baseUrl];

    self.webView.navigationDelegate = self;
    self.webView.UIDelegate = self;
    self.webView.allowsBackForwardNavigationGestures = YES;
    [self.view addSubview:self.webView];
    
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(nonnull WKNavigationAction *)navigationAction decisionHandler:(nonnull void (^)(WKNavigationActionPolicy))decisionHandler {
    
    WKNavigationActionPolicy actionPolicy = WKNavigationActionPolicyAllow;
    //JS调用原生的 这里是做了a标签的href的拦截 约定的字段是666 如果包含该字段就显示弹窗
    NSString *url = navigationAction.request.URL.absoluteString;
    NSLog(@"%@", url);
    if ([url containsString:@"666"]) {
        [self showAlert]; //显示弹窗
    }
    //这句是必须加上的，不然会异常
    decisionHandler(actionPolicy);
    
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    NSLog(@"JS调iOS name : %@ body : %@",message.name,message.body);
    
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    //原生给html传值
    [_webView evaluateJavaScript:@"getValue('23333')" completionHandler:^(id object, NSError * _Nullable error) {
        NSLog(@"%@ %@", object , error);
    }];
    
}

- (void)showAlert {
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"恭喜您中奖了" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *actionGo = [UIAlertAction actionWithTitle:@"去领奖" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *actionCancle = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [alertVC dismissViewControllerAnimated:YES completion:nil];
    }];
    [alertVC addAction:actionGo];
    [alertVC addAction:actionCancle];
    [self presentViewController:alertVC animated:YES completion:nil];
}


- (void)backNative{
//     if ([self.webView canGoBack]) {
//         [self.webView goBack];
//         self.navigationItem.leftBarButtonItems = @[self.backBtn, self.closeBtn];
//     } else {
//         [self closeNative];
//     }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
